import { useState, useEffect } from "react";
import ProductCard from "./ProductCard";
import AddProductForm from "./AddProductForm";
function ProductList() {
  const [products, setProducts] = useState([]);
  const [cartCount, setCartCount] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOrder, setSortOrder] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch products");
        return res.json();
      })
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const handleAddToCart = () => setCartCount(cartCount + 1);

  const handleAddProduct = (newProduct) => {
    setProducts([newProduct, ...products]);
  };

  let filteredProducts = products.filter((product) =>
    product.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (sortOrder === "low-high") {
    filteredProducts = [...filteredProducts].sort((a, b) => a.price - b.price);
  } else if (sortOrder === "high-low") {
    filteredProducts = [...filteredProducts].sort((a, b) => b.price - a.price);
  }

  return (
    <div className="page-content">
      <header className="shop-header">
        <h1 className="store-title">नमस्ते सबैजनालाई स्वागतम्</h1>
        <p className="cart-count">🛒 Cart: {cartCount}</p>
      </header>

      <AddProductForm onAddProduct={handleAddProduct} />

      <input
        type="text"
        placeholder="Search products..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      />

      <select
        value={sortOrder}
        onChange={(e) => setSortOrder(e.target.value)}
        className="sort-dropdown"
      >
        <option value="">Sort by Price</option>
        <option value="low-high">Low → High</option>
        <option value="high-low">High → Low</option>
      </select>

      {loading && <p>Loading products...</p>}
      {error && <p style={{ color: "red" }}>Error: {error}</p>}

      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "25px",
          marginTop: "25px",
          justifyContent: "center",
        }}
      >
        {!loading &&
          !error &&
          filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              name={product.title}
              price={product.price}
              image={product.image}
              rating={product.rating?.rate || 0}
              onAddToCart={handleAddToCart}
            />
          ))}
      </div>
    </div>
  );
}

export default ProductList;
