import PropTypes from "prop-types";
import { Link } from "react-router-dom";

function ProductCard({ id, name, price, image, rating, onAddToCart }) {
  return (
    <div className="product-card">
      <img src={image} alt={name} className="product-image" />
      <h3 className="product-name">{name}</h3>
      <p className="product-price">Price: Rs. {price}</p>
      <p className="product-rating">Rating: ⭐ {rating}</p>
      <button onClick={onAddToCart} className="add-btn">Add to Cart</button>
    </div>
  );
}

ProductCard.propTypes = {
  id: PropTypes.number.isRequired,
  name: PropTypes.string.isRequired,
  price: PropTypes.number.isRequired,
  image: PropTypes.string.isRequired,
  rating: PropTypes.number.isRequired,
  onAddToCart: PropTypes.func.isRequired,
};

export default ProductCard;
