import { useState } from "react";

function AddProductForm({ onAddProduct }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");
  const [category, setCategory] = useState("");
  const [errors, setErrors] = useState({});

  
  const validate = () => {
    const newErrors = {};

    if (!name.trim()) {
      newErrors.name = "Product name is required.";
    }
    if (!price || isNaN(price) || Number(price) <= 0) {
      newErrors.price = "Price must be a positive number.";
    }
    const urlPattern = /^(https?:\/\/.*\.(?:png|jpg|jpeg|gif))$/i;
    if (!urlPattern.test(image)) {
      newErrors.image = "Image URL must be a valid link ending with .png/.jpg/.jpeg/.gif";
    }
    if (!category) {
      newErrors.category = "Category is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      const newProduct = {
        id: Date.now(),
        title: name,
        price: Number(price),
        image,
        category,
        rating: { rate: 0 }, // default rating
      };
      onAddProduct(newProduct);

      
      setName("");
      setPrice("");
      setImage("");
      setCategory("");
      setErrors({});
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
      <div>
        <label>Product Name:</label><br />
        <input value={name} onChange={(e) => setName(e.target.value)} />
        {errors.name && <p style={{ color: "red" }}>{errors.name}</p>}
      </div>

      <div>
        <label>Price:</label><br />
        <input value={price} onChange={(e) => setPrice(e.target.value)} />
        {errors.price && <p style={{ color: "red" }}>{errors.price}</p>}
      </div>

      <div>
        <label>Image URL:</label><br />
        <input value={image} onChange={(e) => setImage(e.target.value)} />
        {errors.image && <p style={{ color: "red" }}>{errors.image}</p>}
      </div>

      <div>
        <label>Category:</label><br />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Select Category</option>
          <option value="electronics">Electronics</option>
          <option value="fashion">Fashion</option>
          <option value="home">Home</option>
          <option value="sports">Sports</option>
        </select>
        {errors.category && <p style={{ color: "red" }}>{errors.category}</p>}
      </div>

      <button type="submit" style={{ marginTop: "10px" }}>Add Product</button>
    </form>
  );
}

export default AddProductForm;
