function Footer() {
  return (
    <footer className="footer">
      <div className="footer-left">
  <h2 className="footer-title">Thank you for visiting our website!</h2>
</div>


      <div className="footer-center">
        <p><strong>Name:</strong> Tashi Phinjo Sherpa</p>
        <p><strong>Email:</strong> tashiphijosherpa@gmail.com</p>
        <p><strong>Phone:</strong> 97423185190</p>
      </div>

      <div className="footer-right">
        <p><strong>Location:</strong> sefal,Kathmandu, Nepal</p>
        <p><strong>Contact:</strong> @Tashi(Whatsapp)</p>
      </div>
    </footer>
  );
}

export default Footer;
