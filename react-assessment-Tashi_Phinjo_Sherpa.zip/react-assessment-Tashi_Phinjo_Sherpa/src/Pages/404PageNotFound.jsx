function NotFound() {
  return (
    <div className="notfound-page">
  <h1 className="notfound-title">404 - Page Not Found</h1>
  <p className="notfound-text">"माफ गर्नुहोस्, तपाईंले खोज्नुभएको पृष्ठ फेला परेन।"</p>
</div>


  );
}

export default NotFound;
