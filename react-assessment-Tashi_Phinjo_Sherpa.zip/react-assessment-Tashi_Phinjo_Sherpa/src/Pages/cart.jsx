function Cart() {
  return (
    <div className="cart-page">
  <h1 className="cart-title">Your Cart</h1>
  <p className="cart-text">कार्टको सुविधाहरू यहाँ हुनेछन्.</p>
</div>


  );
}

export default Cart;
