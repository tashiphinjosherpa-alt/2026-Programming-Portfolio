# React Assessment - Deerwalk Shopping Center-Tashi_Phinjo_Sherpa

## Project Description

This is a React JS assignment-based assessment project. It demonstrates React components, props, state, event handling, hooks, API fetching, controlled forms, validation, and React Router.

## Technologies Used

* React
* Vite
* React Router DOM
* PropTypes
* JavaScript
* CSS
* Fake Store API

## Features

### Section A - Component Basics & Props

* ProductCard component
* Product props: name, price, image, and rating
* ProductList component
* Six or more products
* `.map()` used to display products
* PropTypes used for validation

### Section B - State & Event Handling

* Add to Cart functionality
* Cart count in navbar
* Product search
* Price sorting
* React `useState`

### Section C - Hooks & Data Fetching

* Products fetched from Fake Store API
* `useEffect` used for API fetching
* Loading message and spinner
* Error handling

### Section D - Forms

* Add New Product form
* Product Name
* Price
* Image URL
* Category
* Controlled components
* Form validation
* Inline error messages
* New product added without page reload

### Section E - Routing

Routes included:

* `/` - Product List
* `/product/:id` - Product Details
* `/cart` - Cart Page
* `*` - 404 Not Found

## Installation

Clone or download the project.

Open the project folder in a terminal:

```bash
npm install
```

Start the development server:

```bash
npm run dev
```

Open the local URL shown by Vite in the browser.

## API

This project uses:

https://fakestoreapi.com/products

## Assumptions

* Products are loaded from the Fake Store API.
* Cart data is stored in React state and is reset when the page is refreshed.
* Newly added products are stored in React state and are not saved to a database.
* The project is intended for demonstration and assessment purposes.

## Project Structure

```text
src/
├── components/
│   ├── Navbar.jsx
│   ├── ProductCard.jsx
│   ├── ProductList.jsx
│   ├── AddProductForm.jsx
│   └── Footer.jsx
│
├── pages/
│   ├── Home.jsx
│   ├── ProductDetails.jsx
│   ├── Cart.jsx
│   └── NotFound.jsx
│
├── App.jsx
├── main.jsx
└── index.css

```

## How to Test

1. Open the home page.
2. Check that products are displayed.
3. Search for a product.
4. Test both sorting options.
5. Add products to the cart.
6. Open the cart page.
7. Click a product to view details.
8. Test the Add New Product form.
9. Test invalid form values.
10. Test an invalid URL for the 404 page.
11. Temporarily change the API URL to test the error state.
